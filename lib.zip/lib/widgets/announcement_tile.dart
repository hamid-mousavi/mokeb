// import 'package:flutter/material.dart';
// import '../models/announcement.dart';

// class AnnouncementTile extends StatelessWidget {
//   final Announcement announcement;

//   const AnnouncementTile({required this.announcement});

//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       color: Colors.grey[850],
//       margin: EdgeInsets.symmetric(vertical: 6),
//       child: ListTile(
//         title: Text(announcement.title),
//         subtitle: Text(announcement.description),
//       ),
//     );
//   }
// }
